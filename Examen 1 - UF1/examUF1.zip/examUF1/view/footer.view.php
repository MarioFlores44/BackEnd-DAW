

<footer class="text-center text-lg-start text-white bg-dark mt-5">
    <div class="text-center p-3">
        --- <strong>M07</strong>
    </div>
</footer>