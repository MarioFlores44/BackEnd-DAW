document.getElementById("submit").addEventListener("click", showSpinner);

/**
 * Desoculta el spinner del botó d'enviament
 */
function showSpinner() {
  document.getElementById("spinner").style.display = "";
}