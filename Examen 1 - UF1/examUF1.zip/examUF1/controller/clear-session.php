

<?php

require_once 'session.php';

logout();

?>